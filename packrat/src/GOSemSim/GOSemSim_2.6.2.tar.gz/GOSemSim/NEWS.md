# GOSemSim 2.5.1

+ return NA for deprecated IDs (2018-01-09, Fri)
    - https://support.bioconductor.org/p/105822/#105840
