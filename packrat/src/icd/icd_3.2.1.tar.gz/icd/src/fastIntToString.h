#ifndef FASTINTTOSTRING_H_
#define FASTINTTOSTRING_H_

#include "icd_types.h"
Rcpp::CharacterVector fastIntToStringRcpp(Rcpp::IntegerVector x);

#endif /* FASTINTTOSTRING_H_ */
