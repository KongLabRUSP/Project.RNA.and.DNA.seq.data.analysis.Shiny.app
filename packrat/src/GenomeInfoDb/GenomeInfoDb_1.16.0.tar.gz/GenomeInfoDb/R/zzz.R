.test <- function() BiocGenerics:::testPackage("GenomeInfoDb")

