#ifndef HANDLERS_H
#define HANDLERS_H

#include "rtracklayer.h"

void pushRHandlers();
void popRHandlers();

#endif
