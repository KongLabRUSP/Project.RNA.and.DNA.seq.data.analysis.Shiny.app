#ifndef UTILS_H
#define UTILS_H

#include "rtracklayer.h"

SEXP CharacterList_pasteCollapse(SEXP x, SEXP sep);

#endif
