library(testthat)
library(icd.data)
test_check("icd.data")
